package com.example.project;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.*;
import java.util.ArrayList;
import java.util.Objects;

public class FaceLiteApplication extends Application {

    // Load user data from the "users.txt" file
    private void loadUserData() {
        String fileName = "users.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(",");
                if (userData.length >= 4) {
                    String name = userData[0];
                    String status = userData[1];
                    String picturePath = userData[2];
                    String[] friends = userData[3].replace("[", "").replace("]", "").split(", ");
                    User user = new User(name);
                    user.setStatus(status);
                    user.setPicturePath(picturePath);
                    for (String friend : friends) {
                        user.userAddFriend(friend);
                    }
                    FaceLiteController.getUsers().add(user);
                }
            }
        } catch (IOException e) {
            // Failed to load user data, handle the exception if needed
            //noinspection CallToPrintStackTrace
            e.printStackTrace();
        }
    }

    // Save user data to the "users.txt" file
    public static void saveUserData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt"))) {
            ArrayList<User> users = FaceLiteController.getUsers();
            for (User user : users) {
                writer.write(user.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            // Failed to save user data, handle the exception if needed
            //noinspection CallToPrintStackTrace
            e.printStackTrace();
        }
    }


    @Override
    public void start(Stage stage) {
        try {
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("welcome.fxml")));
            Scene scene = new Scene(root);
            MainStage.mainStage = stage;
            MainStage.mainStage.setScene(scene);
            MainStage.mainStage.setTitle("FaceLite");
            MainStage.mainStage.show();

            // Load user data from file
            loadUserData();

        } catch (Exception e) {
            //noinspection CallToPrintStackTrace
            e.printStackTrace();
        }


    }

    public static void main(String[] args) {
        launch(args);
        saveUserData();
    }
}