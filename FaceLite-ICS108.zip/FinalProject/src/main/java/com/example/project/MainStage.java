package com.example.project;

import javafx.stage.Stage;

public class MainStage {

    //Static variable
    public static Stage mainStage;
}

