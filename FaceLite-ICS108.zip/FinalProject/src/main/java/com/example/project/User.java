package com.example.project;
import java.util.LinkedHashSet;

public class User {
    private final String name;  // The name of the user
    private String imagePath;  // The path to the user's profile picture
    private String status;  // The current status of the user
    private final LinkedHashSet<String> friends;  // A set of the user's friends

    public User(String name){
        this.name = name;
        this.friends= new LinkedHashSet<>();  // Initialize the friends set
        this.status="No current status";  // Set the initial status
        this.imagePath = "noPic.png";  // Set the initial profile picture path
    }

    public String getName(){
        return name;
    }

    public String getPicturePath(){
        return imagePath;
    }

    public void setPicturePath(String imagePath){
        this.imagePath = imagePath;
    }

    public String getStatus(){
        return status;
    }

    public void setStatus(String status){
        this.status = status;
    }

    public void userAddFriend(String friend){
        friends.add(friend);  // Add a friend to the set
    }

    public LinkedHashSet<String> getFriend(){
        return friends;
    }

    @Override
    public String toString(){
        return getName() + "," + getStatus() + "," + getPicturePath() + "," +getFriend().toString();
    }

}