package com.example.project;

// Import necessary JavaFX components
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import java.io.File;
import java.io.IOException;
import java.util.*;

import static javafx.scene.paint.Color.BLACK;
import static javafx.scene.paint.Color.WHITE;

// Controller class handling FaceLite application functionality
public class FaceLiteController {

    // FXML injected components from the corresponding FXML file
    @FXML
    private ImageView logo;
    @FXML
    private Label userName;
    @FXML
    private Label friendsLabel;
    @FXML
    private Label update;
    @FXML
    private Label statusLabel;
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField addFriendTextField;
    @FXML
    private TextField changeStatusTextField;
    @FXML
    private VBox friendList;
    @FXML
    private Circle circle;

    // ArrayList to store User objects
    private static final ArrayList<User> users = new ArrayList<>();

    // Method to retrieve the list of users
    public static ArrayList<User> getUsers() {
        return users;
    }

    // Method to load the welcome screen
    public void welcome() throws IOException {
        // Load the FaceLite view
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("faceLite_view.fxml")));
        Scene scene = new Scene(root);
        // Set the stage and display the scene
        MainStage.mainStage.setScene(scene);
        MainStage.mainStage.setTitle("FaceLite");
        MainStage.mainStage.show();
    }

    // Method to navigate to the home screen
    public void home() throws IOException {
        // Load the welcome screen
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("welcome.fxml")));
        Scene scene = new Scene(root);
        // Set the stage and display the scene
        MainStage.mainStage.setScene(scene);
        MainStage.mainStage.setTitle("FaceLite");
        MainStage.mainStage.show();
    }

    // Method to display the FaceLite logo
    public void showLogo() {
        Image faceLiteLogo = new Image("FaceLiteLogo.png");
        logo.setImage(faceLiteLogo);
    }

    // Method to clear displayed information
    public void clear() {
        showLogo();
        userName.setText("");
        friendsLabel.setText("");
        statusLabel.setText("");
        circle.setFill(null);
        circle.setStroke(WHITE);
        friendList.getChildren().clear();
    }

    // Method to add a new user
    public void add() {
        showLogo();
        try {
            String name = nameTextField.getText();
            boolean userExists = false;
            friendList.getChildren().clear();

            // Check if the name field is not empty
            if (!name.isEmpty()) {
                for (User user : users) {
                    // Check if the user with the given name already exists
                    if (user.getName().equals(name)) {
                        userExists = true;
                        break;
                    }
                }
                // If user exists, display a message, else add the user
                if (userExists) {
                    clear();
                    update.setText("A profile with the name " + name + " already exists");
                } else {
                    addUser(name);
                }
            }
        } catch (Exception e) {
            userName.setText("Error");
        }
    }

    /**
     * Adds a new user with the specified name to the application.
     *
     * @param name The name of the user to be added.
     */
    public void addUser(String name) {
        // Display the FaceLite logo
        showLogo();
        // Set the user name and create a new User object
        userName.setText(name);
        users.add(new User(name));
        // Set initial values for the user interface elements
        friendsLabel.setText("Friends: ");
        statusLabel.setText("No current status");
        update.setText("New profile created");
        Image newImage = new Image("noPic.png");
        circle.setFill(new ImagePattern(newImage));
        circle.setStroke(BLACK);
    }


    // Method to change the status of the current user
    public void changeStatus() {
        try {
            showLogo();
            String name = nameTextField.getText();
            String status = changeStatusTextField.getText();
            if (!users.isEmpty()) {
                if (!status.isEmpty()) {
                    // Update the status and display a message
                    statusLabel.setText(status);
                    update.setText("Status updated to: " + status);
                }
            }
            // Find the user and update their status
            for (User user : users) {
                if (user.getName().equals(name)) {
                    user.setStatus(status);
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }


    // Method to display user details
    public void lookup() {
        showLogo();
        try {
            if (!users.isEmpty()) {
                friendList.getChildren().clear();
                String name = nameTextField.getText();
                if (!users.isEmpty()) {
                    for (User user : users) {
                        if (user.getName().equals(name)) {
                            // Display user details
                            userName.setText(name);
                            friendsLabel.setText("Friends: ");
                            statusLabel.setText(user.getStatus());
                            update.setText("Displaying " + name);
                            Image newImage = new Image(user.getPicturePath());
                            circle.setFill(new ImagePattern(newImage));
                            circle.setStroke(BLACK);
                            for (String friend : user.getFriend()) {
                                Label friendLabel = new Label();
                                friendLabel.setText(friend);
                                friendList.getChildren().add(friendLabel);
                            }
                            break;
                        } else {
                            clear();
                            update.setText("A profile with the name " + name + " does not exist");
                        }
                    }
                } else {
                    clear();
                    update.setText("A profile with the name " + name + " does not exist");
                }

            }


        } catch (Exception e) {
            userName.setText("Error");
        }
    }

    // Method to change the profile picture of the current user
    public void changePicture() {
        showLogo();
        try {
            if (!users.isEmpty()) {
                String name = nameTextField.getText();
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Select Picture");
                File selectedFile = fileChooser.showOpenDialog(null);

                if (selectedFile != null) {
                    // Set the selected image as the profile picture
                    String imagePath = selectedFile.toURI().toString();
                    Image newImage = new Image(imagePath);
                    circle.setFill(new ImagePattern(newImage));
                    circle.setStroke(BLACK);
                    update.setText("Picture updated");

                    // Find the user and update their picture path
                    for (User user : users) {
                        if (user.getName().equals(name)) {
                            user.setPicturePath(imagePath);
                            break;
                        }
                    }
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    // Method to add a friend to the current user's friend list
    public void addFriend() {
        try {
            showLogo();
            String friendName = addFriendTextField.getText();
            if (!users.isEmpty()) {
                if (!friendName.isEmpty()) {
                    // Check if the user is trying to add themselves as a friend
                    if (friendName.equals(userName.getText())) {
                        update.setText("You cannot add your profile as a friend");
                    } else {
                        boolean profileExists = false;
                        User friendProfile = null;

                        // Check if the friend's profile exists
                        for (User user : users) {
                            if (friendName.equals(user.getName())) {
                                profileExists = true;
                                friendProfile = user;
                                break;
                            }
                        }
                        if (profileExists) {
                            // Check if the friend is already in the current user's friend list
                            boolean alreadyFriends = false;
                            for (String friend : friendProfile.getFriend()) {
                                if (friend.equals(userName.getText())) {
                                    alreadyFriends = true;
                                    break;
                                }
                            }
                            if (alreadyFriends) {
                                update.setText("You are already friends with " + friendName);
                            } else {
                                // Add the friend and update friend lists of both users
                                update.setText(friendName + " added as a friend");
                                friendProfile.userAddFriend(userName.getText());
                                User currentUser = null;
                                for (User user : users) {
                                    if (user.getName().equals(userName.getText())) {
                                        currentUser = user;
                                        break;
                                    }
                                }
                                if (currentUser != null) {
                                    currentUser.userAddFriend(friendName);
                                }
                            }
                        } else {
                            update.setText("A profile with the name " + friendName + " does not exist");
                        }
                    }
                    // Update the displayed friend list
                    friendList.getChildren().clear();
                    User currentUser = null;
                    for (User user : users) {
                        if (user.getName().equals(userName.getText())) {
                            currentUser = user;
                            break;
                        }
                    }
                    if (currentUser != null) {
                        for (String friend : currentUser.getFriend()) {
                            Label friendLabel = new Label();
                            friendLabel.setText(friend);
                            friendList.getChildren().add(friendLabel);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    // Method to delete the user's profile
    @FXML
    public void delete() {
        try {
            showLogo();
            String name = nameTextField.getText();
            if (!users.isEmpty()) {
                for (User user : users) {
                    // Check if the user with the given name already exists
                    if (user.getName().equals(name)) {
                        // Display a confirmation dialog for profile deletion
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                        alert.setTitle("Confirmation Dialog");
                        alert.setHeaderText("Delete Confirmation");
                        alert.setContentText("Are you sure you want to delete your profile?");
                        ButtonType confirmButton = new ButtonType("Confirm");
                        ButtonType cancelButton = new ButtonType("Cancel");
                        alert.getButtonTypes().setAll(confirmButton, cancelButton);

                        // If confirmed, delete the profile and update friend lists
                        alert.showAndWait().ifPresent(response -> {
                            if (response == confirmButton) {
                                Iterator<User> iterator = users.iterator();
                                while (iterator.hasNext()) {
                                    User user1 = iterator.next();
                                    LinkedHashSet<String> friends = user1.getFriend();
                                    friends.remove(name);
                                    if (user1.getName().equals(name)) {
                                        iterator.remove();
                                    }
                                }

                                clear();
                                update.setText("Profile of " + name + " deleted");
                            }
                        });
                    }
                    else{
                        update.setText("A profile with the name " + name + " does not exist");
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


}



